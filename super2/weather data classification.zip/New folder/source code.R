datadirectory<-"D:/R/"
data<-read.csv(paste(datadirectory,'sunnyData.csv',sep = ""),header = TRUE)
data
dtMatrix <- create_matrix(data["Text"])
dtMatrix
container <- create_container(dtMatrix, data$IsSunny, trainSize=1:35, virgin=FALSE)
model <- train_model(container, "SVM", kernel="linear", cost=1)
predictionData <- list("the day is very rainy", "very hot climate", "people in the dry region has less water", "very sunny", "this is another cloudy day")
trace("create_matrix", edit=T)
predMatrix <- create_matrix(predictionData, originalMatrix=dtMatrix)
predMatrix
predSize = length(predictionData);
predictionContainer <- create_container(predMatrix, labels=rep(0,predSize), testSize=1:predSize, virgin=FALSE)
results <- classify_model(predictionContainer, model)
results


